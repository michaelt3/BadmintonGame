#ifndef MISC_H_
#define MISC_H_

#include "mbed.h"
#include "game_synchronizer.h"
#include "SDFileSystem.h"
#include "playSound.h"
#include "wave_player.h"
#include "game.h"

#define U_BUTTON        0
#define R_BUTTON        1
#define D_BUTTON        2
#define L_BUTTON        3

// feel free to change these values below
#define ACC_THRESHOLD   0.2
#define TIME_STEP       0.05
#define GND_LVL         10

#define SKY_COL         0x7ec0ee
#define GND_COL         0xcd853f
#define P1_COL          0xff0000
#define P2_COL          0xff
#define SHUT_COL        0

#endif