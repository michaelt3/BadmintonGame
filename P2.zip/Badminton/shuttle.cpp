#include "misc.h"

extern Serial pc;

// Initializes struct members with default values. Feel free to change any
// of these.
//      x0 and y0 are initial positions at the beginning of each volley.
//      vx0 and vy0 and initial velocities at the beginning of each volley.
//      x and y and current positions of the shuttle.
//      time_elapsed is cumulative time the shuttle has spent in air since
//          last volley.
//      is_live is the boolean value of whether or not the shuttle has been
//          served.
//      last_possession is a racket* pointing to the last player to touch
//          the shuttle.
void init_shuttle(shuttle *s, racket *r)
{
    // TODO: Appropriately initialize shuttle member variables.
    s->x = r->x;
    s->y = 14;
    s->x0 = 0;
    s->y0 = 0;
    s->vx0 = 2.1; 
    s->vy0 = 7.8;
    s->time_elapsed = 0;
    s->is_live = false;
    s->last_possession = r;
}

// Primary movement function of shuttle. Determines position or shuttle using
// kinematic equations and returns appropriate COLLISION_CODE.
