#ifndef SHUTTLE_H_
#define SHUTTLE_H_

#include "misc.h"

// COLLISION_CODES returned by update_shuttle. Simplifies processing in main.
enum Collision_Codes
{
    NO_COLLISION,           // no collision detected
    CONT_VOLLEY,            // collision detected; continue volley
    POINT_P1,               // player 1 scores
    POINT_P2                // player 2 scores
};

typedef struct shuttle
{
    int x0, y0;                 // initial positions per volley // false if P1 touched last, true if P2 touched last 
    float vx0, vy0;             // initial velocities per volley
    int x, y;                   // current positions of shuttle
    float time_elapsed;         // cumulative time in air
    bool is_live;               // if shuttle has been served
    racket *last_possession;    // last player to touch shuttle
          // false if P1 touched last, true if P2 touched last 
} shuttle;

// Initialize shuttle struct members. Racket* parameter is player starting with
// shuttle.
void init_shuttle(shuttle*, racket*);


#endif