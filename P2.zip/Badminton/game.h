#ifndef GAME_H_
#define GAME_H_

// COLLISION_CODES returned by update_shuttle. Simplifies processing in main.
enum Collision_Codes
{
    NO_COLLISION,               // no collision detected
    CONT_VOLLEY,                // collision detected; continue volley
    POINT_P1,                   // player 1 scores
    POINT_P2                    // player 2 scores
};

typedef struct racket
{
    int player;         // PLAYER1 or PLAYER2
    int x, y;           // center x and y positions
    int width, height;  // width and height of racket
    int x0, y0;         // initial positions before jump
    float vx0, vy0;     // initial velocities of racket
    float time_elapsed; // cumulative time in air
    bool has_jumped;    // if the player has jumped and is in the air
    int points;         // points per player
} racket;

typedef struct shuttle
{
    int x0, y0;                 // initial positions per volley
    float vx0, vy0;             // initial velocities per volley
    int x, y;                   // current positions of shuttle
    float time_elapsed;         // cumulative time in air
    bool is_live;               // if shuttle has been served
    racket *last_possession;    // last player to touch shuttle
} shuttle;

// Initialize racket struct members. Int parameter identifies PLAYER1 or PLAYER2.
void init_racket(racket*, int,int);

// Calculates next position, both running and jumping, of racket using kinematic
// equations.

// Initialize shuttle struct members. Racket* parameter is player starting with
// shuttle.
void init_shuttle(shuttle*, racket*);


#endif