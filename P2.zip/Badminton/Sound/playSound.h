#ifndef PLAYSOUND_H__
#define PLAYSOUND_H__

void playSound(char * wav);

#endif //PLAYSOUND_H__