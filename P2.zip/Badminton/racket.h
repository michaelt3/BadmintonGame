#ifndef RACKET_H_
#define RACKET_H_

#include "misc.h"

typedef struct racket
{
    int player;         // PLAYER1 or PLAYER2
    int x, y;           // center x and y positions
    int width, height;  // width and height of racket
    int x0, y0;         // initial positions before jump
    float vx0, vy0;     // initial velocities of racket
    float time_elapsed; // cumulative time in air
    bool has_jumped;    // if the player has jumped and is in the air
    int points;         // points per player
    int difficulty;
} racket;

// Initialize racket struct members. Int parameter identifies PLAYER1 or PLAYER2.
void init_racket(racket*, int, int);

#endif