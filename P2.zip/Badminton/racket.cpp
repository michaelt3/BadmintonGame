#include "misc.h"
extern Serial pc;

// Initializes struct members with default values. Feel free to change any
// of these.
//      player is PLAYER1 or PLAYER2.
//      x and y positions map to center point of racket.
//      width and height dictate the overall width and height.
//      x0 and y0 are the initial positions; useful for jump calculations.
//      vx0 and vy0 are the initial velocities; useful for jump calculations.
//      time_elapsed is the cumulative time the racket spends in the air; again,
//          useful for jump calculations.
//      has_jumped is a boolean flag to prevent x movement while jumping (for
//          "realism").
//      points is the number of points for each player.
void init_racket(racket *r, int player, int difficulty)
{
    // TODO: Appropriately initialize racket member variables.
    r->player = player;
    switch (r->player)
    {
        case 1:
            r->x = 22; 
            r->y = 11;
            break;
        case 2:
            r->x = 106;
            r->y = 11; 
            break;     
    }
    if (difficulty == 0) //Easy difficulty
    {
        r-> width = 22;
    } 
    if (difficulty == 1) //Normal difficulty
    {
        r->width = 15;
    }
    if (difficulty == 2) //Hard difficulty
    {
        r->width = 8;
    }
    r->height = 3;
    r->x0 = 0;
    r->y0 = 0;
    r->vx0 = 0;
    r->vy0 = 0;
    r->time_elapsed = 0;
    r->has_jumped = false;
    r->points = 0;
}

// Primary movement function of rackets. Handles running and jumping.

